# Snake

### Description.
The snake game package is separated in:
- Main
- Food
- Scoreboard
- Snake

### Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install Snake

```bash
pip install Snake
 ```

## Author
Enzo Scalassara